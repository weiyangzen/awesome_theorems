/-
Copyright 2025 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/

import FormalConjecturesUtil

/-!
# Erdős Problem 392

*Reference:* [erdosproblems.com/392](https://www.erdosproblems.com/392)
-/

open Filter

open scoped Nat

namespace Erdos392

/--
Let $A(n)$ denote the least value of $t$ such that
$$
  n! = a_1 \cdots a_t
$$
with $a_1 \leq \cdots \leq a_t\leq n^2$. Then
$$
  A(n) = \frac{n}{2} - \frac{n}{2\log n} + o\left(\frac{n}{\log n}\right).
$$
-/
@[category research solved, AMS 11, formal_proof using lean4 at "https://github.com/AlexKontorovich/PrimeNumberTheoremAnd/blob/d82a35ecc798ada27f82a88b559f25b753f63a73/PrimeNumberTheoremAnd/IEANTN/Erdos392.lean"]
theorem erdos_392 (A : ℕ → ℕ) (h : ∀ n > 0,
    IsLeast { t + 1 | (t) (_ : ∃ a : Fin (t + 1) → ℕ, (n)! = ∏ i, a i ∧
      Monotone a ∧ a (Fin.last t) ≤ n ^ 2) } (A n)) :
    ((fun (n : ℕ) => (A n - n / 2 + n / (2 * Real.log n) : ℝ)) =o[atTop] fun n => n / Real.log n)
  := by
  sorry

/--
If we change the condition to $a_t \leq n$ it can be shown that
$$
  A(n) = n - \frac{n}{\log n} + o\left(\frac{n}{\log n}\right)
$$
-/
@[category research solved, AMS 11]
theorem erdos_392.variants.lower (A : ℕ → ℕ)
    (hA : ∀ n > 0, IsLeast
      { t + 1 | (t) (_ : ∃ a : Fin (t + 1) → ℕ, (n)! = ∏ i, a i ∧
        Monotone a ∧ a (Fin.last t) ≤ n) } (A n)) :
    (fun (n : ℕ) => (A n - n + n / Real.log n : ℝ)) =o[atTop] fun n => n / Real.log n := by
  sorry

/--
Cambie has observed that a positive answer follows from the result above with $a_t \leq n$, simply
by pairing variables together, e.g. taking $a'_i = a_{2i-1}a_{2i}$ (and the lower bound follows from
Stirling's approximation).
-/
@[category research solved, AMS 11]
theorem erdos_392.variants.implication (h : type_of% erdos_392) :
    type_of% erdos_392.variants.lower := by
  sorry

end Erdos392
